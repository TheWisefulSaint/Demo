<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<html>
    <head>
        <meta charset="UTF-8">
        <title>Register Account</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://kit.fontawesome.com/24c9630061.js" crossorigin="anonymous"></script>
        <style>
            *{
                overflow-y:hidden;
                overflow-x:hidden;
            }
            body{ 
                background-image:url('../Pictures/BackgroundPic.jpeg');
                background-repeat:no-repeat;
                background-attachment: fixed;
                background-size: cover;
                font: 14px sans-serif;
            }
            .section
            {
                text-align: center;
                font-size: 30px;
                color: white;
                display: flex;
                align-items: center;
                justify-content: center;
                width:100%;
            }
            .top-section
            {
                background-color:limegreen;   
                height:25%;
            }
            .mid-section
            {
                background-color:orange;
            }
            .bot-section
            {
                background-color: hotpink;
            }
        </style>
    </head>
    <body>
        <div class="d-flex align-items-center justify-content-center vh-100">
            <form class="bg-light h-75">
                <div class="float-start w-50">
                    <img src="../Pictures/RegisterPagePic.png" alt=""/>
                </div>
                <div class="float-end w-50">
                    <h1 class="m-4">Register Page</h1>
                    <p class="m-4">Please enter your details to register an account</p>
                    <div class="form-control-sm p-0 m-4">
                        <label for="email" class="form-label">Email address</label>
                        <input type="email" class="form-control" id="email">
                    </div>
                    <div class="form-control-sm p-0 m-4">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username">
                    </div>
                    <div class="form-control-sm p-0 m-4">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password">
                    </div>
                    <div class="form-control-sm p-0 m-4">
                        <label for="confirmPassword" class="form-label">Confirm Password</label>
                        <input type="password" class="form-control" id="confirmPassword">
                    </div>
                    <div class="ms-4 form-check form-control-sm">
                        <input type="checkbox" class="form-check-input" id="agree">
                        <label class="form-check-label" for="agree">I agree to the terms and conditions in creating an account</label>
                    </div>
                    <p class="m-4">Already have an account? <a href="loginpage.php">Click here to login</a>.</p> 
                    <button onclick="history.back()" class="btn btn-success m-4 float-start">Back</button>
                    <button type="submit" class="btn btn-primary m-4 float-end">Register</button>
                </div>
            </form>
        </div>
  </body>
</html>

