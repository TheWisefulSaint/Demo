<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Home Page</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://kit.fontawesome.com/24c9630061.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
        <link href="../CssPages/footer.css" rel="stylesheet" type="text/css"/>
        <link href="../CssPages/homepage.css" rel="stylesheet" type="text/css"/>
        <link href="../CssPages/navigationbar.css" rel="stylesheet" type="text/css"/>
        <script>
            $(document).ready(function(){
                $("#announcementModal").modal('show');
            });
        </script>
    </head>
    <body>
        <!-- Top navigation -->
            <nav class="navbar navbar-expand-lg text-white top fixed-top bg-white" style="height:9%">
                <img src="../Pictures/japan_logo.png" class="img-fluid ps-3" alt="" style="height:100%" class="p-0 m-0"/>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="" role="button" ><i class="fa fa-bars" aria-hidden="true" style="color:light-grey"></i></span>
                </button>

                <div class="collapse navbar-collapse nav-left" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item active">
                            <a class="nav-link ps-5" href="homepage.php" style="font-size:20px; color: black;">Home</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link ps-5 dropdown-toggle" data-bs-toggle="dropdown" role="button" href="eventPage.php" style="font-size:20px; color: black;">Event</a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="eventpage.php">Link 1</a></li>
                                <li><a class="dropdown-item" href="eventpage.php">Link 2</a></li>
                                <li><a class="dropdown-item" href="eventpage.php">Link 3</a></li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link ps-5" href="aboutuspage.php" style="font-size:20px; color: black;">About Us</a>
                        </li>
                        <li class="nav-item">
                            <button type="button" class="btn btn-nav nav-link ps-5" data-bs-toggle="modal" data-bs-target="#cartModal" style="font-size:20px;color:black"><i class="fa fa-shopping-cart"></i></button>
                        </li>
                    </ul>
                </div>
                <div class="collapse navbar-collapse nav-right" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <button type="button" class="btn btn-nav nav-link ps-5" data-bs-toggle="modal" data-bs-target="#profileModal" style="font-size:20px; color: black;">Profile</button>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link ps-5 pe-5"  href="" style="font-size:20px; color: black;">Logout</a>
                        </li>
                    </ul>
                </div>
<!--                <div class="collapse navbar-collapse nav-right" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link ps-5" href="registerpage.php" style="font-size:20px; color: black;">Register</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link ps-5 pe-5"  href="loginpage.php" style="font-size:20px; color: black;">Login</a>
                        </li>
                    </ul>
                </div>-->
            </nav>
        
        <!-- Event Slideshow -->
        <div id="main-carousel" class="carousel slide bg-dark" data-bs-ride="carousel">
            <!-- The slideshow/carousel -->
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="../Pictures/dotonbori.png" alt="" class="d-block mx-auto" style="width:60%"/>
                </div>
                <div class="carousel-item">
                    <img src="../Pictures/fuji.png" alt="" class="d-block mx-auto" style="width:60%"/>
                </div>
                <div class="carousel-item">
                    <img src="../Pictures/himeji.png" alt="" class="d-block mx-auto" style="width:60%"/>
                </div>
            </div>

            <!-- Left and right controls/icons -->
            <button class="carousel-control-prev" type="button" data-bs-target="#main-carousel" data-bs-slide="prev">
              <span class="carousel-control-prev-icon"></span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#main-carousel" data-bs-slide="next">
              <span class="carousel-control-next-icon"></span>
            </button>
        </div>
        
        <div class="container-fluid mt-2 p-5 content1">
            <div class="border border-end-0 border-top-0 border-bottom-0 border-dark">
                <h2 class="ps-5">About Japan</h2>
                <div class="embed-responsive ratio ratio-16x9 w-50 ms-5">
                    <iframe src="https://www.youtube.com/embed/p-I3LhCrsq0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
                <p class="ps-5 pe-5" style="font-family: system-ui;">
                    <br>
                    Japan (Japanese: Nippon <i>[ɲippoꜜɴ]</i> (About this soundlisten) or Nihon <i>[ɲippoꜜɴ]</i>) is an island country in East Asia, located in the northwest Pacific Ocean. 
                    It is bordered on the west by the Sea of Japan, and extends from the Sea of Okhotsk in the north toward the East China Sea and Taiwan in the south. 
                    Part of the Ring of Fire, Japan spans an archipelago of 6852 islands covering 377,975 square kilometers (145,937 sq mi); the five main islands are Hokkaido, Honshu, Shikoku, Kyushu, and Okinawa. 
                    Tokyo is Japan's capital and largest city; other major cities include Yokohama, Osaka, Nagoya, Sapporo, Fukuoka, Kobe, and Kyoto.
                    <br><br>
                    Japan is the eleventh-most populous country in the world, as well as one of the most densely populated and urbanized. 
                    About three-fourths of the country's terrain is mountainous, concentrating its population of 125.36 million on narrow coastal plains. 
                    Japan is divided into 47 administrative prefectures and eight traditional regions. The Greater Tokyo Area is the most populous metropolitan area in the world, with more than 37.4 million residents.
                </p>
            </div>
        </div>
        
        <div class="container-fluid p-5 content2">
            <div class="border border-end-0 border-top-0 border-bottom-0 border-dark">
                <h2 class="ps-5">Japan's Famous Landmarks</h2>
                <br>
                <div class="text-center">
                    <div class="row">
                        <div class="col ps-5"><h4>Shibuya Crossing</h4></div>
                        <div class="col ps-5"><h4>Arashiyama Bamboo Crossing</h4></div>
                        <div class="col ps-5"><h4>Mount Fuji</h4></div>
                    </div>
                    <div class="row">
                        <div class="col img-fluid ps-5"><img src="../Pictures/shibuya.png" style="width:100%;"></div>
                        <div class="col img-fluid ps-5"><img src="../Pictures/arashiyama.png" style="width:100%;"></div>
                        <div class="col img-fluid ps-5"><img src="../Pictures/fuji.png" style="width:100%;"></div>
                    </div>
                    <div class="row">
                        <div class="col ps-5">Often called the world’s busiest pedestrian scramble, Shibuya Crossing has become a symbol of modern Tokyo.</div>
                        <div class="col ps-5">The beauty and mystery of the Arashiyama Bamboo Grove in Kyoto have never been replicated anywhere else on Earth.</div>
                        <div class="col ps-5">With its wide stature and snow-capped peak, Mount Fuji is immediately recognizable at a glance. This beautiful mountain near Tokyo has become a symbol of Japan.</div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col ps-5"><h4>Ashikaga Flower Park</h4></div>
                        <div class="col ps-5"><h4>Dotonbori</h4></div>
                        <div class="col ps-5"><h4>Himeji Castle</h4></div>
                    </div>
                    <div class="row">
                        <div class="col img-fluid ps-5"><img src="../Pictures/ashikaga.png" style="width:100%;"></div>
                        <div class="col img-fluid ps-5"><img src="../Pictures/dotonbori.png" style="width:100%;"></div>
                        <div class="col img-fluid ps-5"><img src="../Pictures/himeji.png" style="width:100%;"></div>
                    </div>
                    <div class="row">
                        <div class="col ps-5">Ashikaga Flower Park’s stunning purple wisterias attract thousands of visitors each year. The wisteria bloom in late April to early May.</div>
                        <div class="col ps-5">Osaka’s downtown Dotonbori district is possibly its most visited attraction, famous for its bright neon signboards and tasty delicacies.</div>
                        <div class="col ps-5">Himeji Castle is Japan’s most famous castle and one of the best surviving examples of feudal Edo architecture.</div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col ps-5"><h4>Shirakawa-go</h4></div>
                        <div class="col ps-5"><h4>Nara Park</h4></div>
                        <div class="col ps-5"><h4>Fushimi Inari Taisha</h4></div>
                    </div>
                    <div class="row">
                        <div class="col img-fluid ps-5"><img src="../Pictures/shirakawa.png" style="width:100%;"></div>
                        <div class="col img-fluid ps-5"><img src="../Pictures/nara.png" style="width:100%;"></div>
                        <div class="col img-fluid ps-5"><img src="../Pictures/fushimi.png" style="width:100%;"></div>
                    </div>
                    <div class="row">
                        <div class="col ps-5">A UNESCO World Heritage Site, the picturesque village of Shirakawa-go is one of Japan’s top winter destinations. With the village lit up and covered with a blanket of snow.</div>
                        <div class="col ps-5">Once thought to be messengers of the gods, the local sika deer now roam free in Nara Park and have become an icon of the city.</div>
                        <div class="col ps-5">Fushimi Inari Taisha is a shrine in Kyoto. The long path of brightly colored torii leading up to the shrine has been featured in countless films.</div>
                    </div>
                </div>
            </div>
        </div>
        
        <div>
            <footer class="text-center justify-content-center">
                <ul style="list-style:none; display:flex;" class="justify-content-center pe-0 ps-0 pb-3 pt-5 m-0">
                    <li><a style="text-decoration:none;" class="footer" href="homePage.php">Home</a></li>
                    <li><a style="text-decoration:none;" class="footer" href="login.php">Login</a></li>
                    <li><a style="text-decoration:none;" class="footer" href="cart.php">Booking</a></li>
                    <li><a style="text-decoration:none;" class="footer" href="aboutUs.php">About</a></li>
                </ul>
                <div class="p-0 m-0">&copy 2023 Cookies by <b><i>Japanese Society</i></b> | All rights reserved</div>
            </footer>
        </div>
       
        <!---------------------------------------Modal Part---------------------------------------->
        
        <!--ANNOUNCEMENT MODAL-->
        <div id="announcementModal" class="modal fade" >
            <div class="modal-dialog modal-lg modal-dialog-centered" style="width:400px;height:400px">
                <div class="modal-content p-0">
                    <div class="modal-body p-0 border-0 card">
                        <img src="../Pictures/arashiyama.png" class="card-img-top" style="height:400px;width:400px;" alt=""/>
                        <div class="card-img-overlay card-inverse">
                            <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!--USER MODAL-->
        <!--USE THIS LINK TO LEARN HOW TO UPDATE DATA IN MODAL-->
        <!--https://www.sourcecodester.com/tutorials/php/12989/php-update-data-through-modal-dialog-using-mysqli.html-->
        <div id="profileModal" class="modal fade">
            <div class="modal-dialog modal modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="profileModal">Profile</h5>
                        <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form>
                        <div class="modal-body">
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email address : </label>
                                    <input type="email" class="form-control" id="email">
                                </div>
                                <div class="mb-3">
                                    <label for="username" class="form-label">Username : </label>
                                    <input type="text" class="form-control" id="username">
                                </div>
                                <div class="mb-3">
                                    <label for="password" class="form-label">Password : </label>
                                    <input type="password" class="form-control" id="password">
                                </div>
                                <div class="mb-3">
                                    <label for="phone" class="form-label">Phone Number : </label>
                                    <input type="tel" class="form-control" id="phone">
                                </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger me-auto" data-bs-dismiss="modal">Close</button>
                            <button type="submit" name="update" class="btn btn-success">Register</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <!--CART MODAL-->
        <div id="cartModal" class="modal fade">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="cartModal">Cart</h5>
                        <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        //This depends on you
                    </div>
                </div>
            </div>
        </div>
        
        <script>
            $(document).ready(function(){
              $('[data-toggle="tooltip"]').tooltip();   
            });
        </script>
        
    </body>
</html>
