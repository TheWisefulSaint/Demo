<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://kit.fontawesome.com/24c9630061.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
        <link href="../CssPages/footer.css" rel="stylesheet" type="text/css"/>
        <link href="../CssPages/navigationbar.css" rel="stylesheet" type="text/css"/>
        <style>
            body{
                overflow: none;
            }
        </style>
    </head>
    <body>
        <!-- Top navigation -->
            <nav class="navbar navbar-expand-lg text-white top fixed-top bg-white" style="height:9%">
                <img src="../Pictures/japan_logo.png" class="img-fluid ps-3" alt="" style="height:100%" class="p-0 m-0"/>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="" role="button" ><i class="fa fa-bars" aria-hidden="true" style="color:light-grey"></i></span>
                </button>

                <div class="collapse navbar-collapse nav-left" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item active">
                            <a class="nav-link ps-5" href="homepage.php" style="font-size:20px; color: black;">Home</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link ps-5 dropdown-toggle" data-bs-toggle="dropdown" role="button" href="eventPage.php" style="font-size:20px; color: black;">Event</a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="eventpage.php">Link 1</a></li>
                                <li><a class="dropdown-item" href="eventpage.php">Link 2</a></li>
                                <li><a class="dropdown-item" href="eventpage.php">Link 3</a></li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link ps-5" href="aboutuspage.php" style="font-size:20px; color: black;">About Us</a>
                        </li>
                        <li class="nav-item">
                            <button type="button" class="btn btn-nav nav-link ps-5" data-bs-toggle="modal" data-bs-target="#cartModal" style="font-size:20px;color:black"><i class="fa fa-shopping-cart"></i></button>
                        </li>
                    </ul>
                </div>
                <div class="collapse navbar-collapse nav-right" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <button type="button" class="btn btn-nav nav-link ps-5" data-bs-toggle="modal" data-bs-target="#profileModal" style="font-size:20px; color: black;">Profile</button>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link ps-5 pe-5"  href="" style="font-size:20px; color: black;">Logout</a>
                        </li>
                    </ul>
                </div>
<!--                <div class="collapse navbar-collapse nav-right" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link ps-5" href="registerpage.php" style="font-size:20px; color: black;">Register</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link ps-5 pe-5"  href="loginpage.php" style="font-size:20px; color: black;">Login</a>
                        </li>
                    </ul>
                </div>-->
            </nav>
        
        <!--About Japan Society-->
        <div class="text-center">
            <img src="../Pictures/AboutUsPic.png" class="mx-auto d-block"/>
            <h2 class="pt-3">About Japanese Society</h2>
            <p class="pt-3" style="padding-left:20%; padding-right:20%; font-size:18px; text-align: justify; line-height: 1.5em;">
                Japan Society is the premier organization connecting Japanese arts, culture, business, and society with audiences in Tunku Abdul Rahman University College and 
                around the world.
                <br><br>
                At Japan Society, we are inspired by the Japanese concept of forging deep connections to bind people together. We are committed to telling the story of Japan while 
                strengthening connections within the college campus and building new bridges beyond. In over years of work, we’ve inspired students by establishing ourselves as pioneers 
                in supporting international exchanges in arts and culture, business and policy, as well as education between Japanese's culture and ours.
                <br><br>
                Now, more than ever, we strive to convene important conversations on topics that bind our two cultures together, to know the difference between both cultures and 
                respecting the differences. Preventing ignorance and argumments within our society about their culture. Learning and understanding is the best to reach an agreement and 
                mutual respect between both cultures.
                <br>
                <br>
            </p>
        </div>
        
        
        <!--About Team-->
        <div class="p-2 m-0 bg-dark text-white">
            <h2 class="text-center pt-5">About Our Team</h2>
            <div class="row mt-5">
                <div class="col-sm-3"></div>
                <div class="col-sm-2">
                    <img src="../Pictures/marson.png" class="rounded-circle w-100">
                </div>
                <div class="col-sm-6 ms-5 mt-5">
                    <h2>Marson Lee</h2>
                    <br>
                    <p style="font-size:24px;">Person In Charge &nbsp: &nbsp Customer Side</p>
                    <br>
                    <p style="font-size:24px;">Part Handling &nbsp: &nbsp Content Creation and Organization,</p>
                    <p style="font-size:24px;">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp Website Design, Coding, Planning </p> 
                </div>
                <div class="col-sm-1"></div>
            </div>
            <hr class="w-75 mx-auto">
            <div class="row mt-5">
                <div class="col-sm-3"></div>
                <div class="col-sm-5 ms-5 mt-5">
                    <h2>Mikael Koay</h2>
                    <br>
                    <p style="font-size:24px;">Person In Charge &nbsp: &nbsp Customer Side</p>
                    <br>
                    <p style="font-size:24px;">Part Handling &nbsp: &nbsp Website Design, Website Development, Content Writing and Assembly, Coding</p>
                </div>
                <div class="col-sm-2">
                    <img src="../Pictures/koay.jpg"  class="rounded-circle w-100">
                </div>
                <div class="col-sm-1"></div>
            </div>
            <hr class="w-75 mx-auto">
            <div class="row mt-5 pb-5">
                <div class="col-sm-3"></div>
                <div class="col-sm-2">
                    <img src="../Pictures/xian.png" class="rounded-circle w-100">
                </div>
                <div class="col-sm-6 ms-5 mt-5">
                    <h2>Justin Cheah</h2>
                    <br>
                    <p style="font-size:24px;">Person In Charge &nbsp: &nbsp Admin Side</p>
                    <br>
                    <p style="font-size:24px;">Part Handling &nbsp: &nbsp Functionality, Database, Coding </p>   
                </div>
                <div class="col-sm-1"></div>
            </div>
        </div>
        
        <div>
            <footer class="text-center justify-content-center">
                <ul style="list-style:none; display:flex;" class="justify-content-center pe-0 ps-0 pb-3 pt-5 m-0">
                    <li><a style="text-decoration:none;" class="footer" href="homePage.php">Home</a></li>
                    <li><a style="text-decoration:none;" class="footer" href="login.php">Login</a></li>
                    <li><a style="text-decoration:none;" class="footer" href="cart.php">Booking</a></li>
                    <li><a style="text-decoration:none;" class="footer" href="aboutUs.php">About</a></li>
                </ul>
                <div class="p-0 m-0">&copy 2023 Cookies by <b><i>Japanese Society</i></b> | All rights reserved</div>
            </footer>
        </div>
        
        <!---------------------------------------Modal Part---------------------------------------->
        
        <!--USER MODAL-->
        <!--USE THIS LINK TO LEARN HOW TO UPDATE DATA IN MODAL-->
        <!--https://www.sourcecodester.com/tutorials/php/12989/php-update-data-through-modal-dialog-using-mysqli.html-->
        <div id="profileModal" class="modal fade">
            <div class="modal-dialog modal modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="profileModal">Profile</h5>
                        <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="email" class="form-label">Email address : </label>
                                <input type="email" class="form-control" id="email">
                            </div>
                            <div class="mb-3">
                                <label for="username" class="form-label">Username : </label>
                                <input type="text" class="form-control" id="username">
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password : </label>
                                <input type="password" class="form-control" id="password">
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="form-label">Phone Number : </label>
                                <input type="tel" class="form-control" id="phone">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger me-auto" data-bs-dismiss="modal">Close</button>
                            <button type="submit" name="update" class="btn btn-success">Register</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <!--CART MODAL-->
        <div id="cartModal" class="modal fade">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="cartModal">Cart</h5>
                        <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        //This depends on you
                    </div>
                </div>
            </div>
        </div>
        
    </body>
</html>
