<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://kit.fontawesome.com/24c9630061.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
        <link href="../CssPages/footer.css" rel="stylesheet" type="text/css"/>
        <link href="../CssPages/navigationbar.css" rel="stylesheet" type="text/css"/>
        <style>
            body{
                overflow: none;
            }
            @media (max-width: 767px) {
                .carousel-inner .carousel-item > div {
                    display: none;
                }
                .carousel-inner .carousel-item > div:first-child {
                    display: block;
                }
            }

            .carousel-inner .carousel-item.active,
            .carousel-inner .carousel-item-next,
            .carousel-inner .carousel-item-prev {
                display: flex;
            }

            /* medium and up screens */
            @media (min-width: 768px) {

                .carousel-inner .carousel-item-end.active,
                .carousel-inner .carousel-item-next {
                  transform: translateX(25%);
                }

                .carousel-inner .carousel-item-start.active, 
                .carousel-inner .carousel-item-prev {
                  transform: translateX(-25%);
                }
            }

            .carousel-inner .carousel-item-end,
            .carousel-inner .carousel-item-start { 
              transform: translateX(0);
            }
        </style>
    </head>
    <body>
        <!-- Top navigation -->
        <nav class="navbar navbar-expand-lg text-white top fixed-top bg-white" style="height:9%;">
            <img src="../Pictures/japan_logo.png" class="img-fluid ps-3" alt="" style="height:100%" class="p-0 m-0"/>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="" role="button" ><i class="fa fa-bars" aria-hidden="true" style="color:light-grey"></i></span>
            </button>

            <div class="collapse navbar-collapse nav-left" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item active">
                        <a class="nav-link ps-5" href="homepage.php" style="font-size:20px; color: black;">Home</a>
                    </li>
                    <li class="nav-item dropdown">
                            <a class="nav-link ps-5 dropdown-toggle" data-bs-toggle="dropdown" role="button" href="eventPage.php" style="font-size:20px; color: black;">Event</a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="eventpage.php">Link 1</a></li>
                                <li><a class="dropdown-item" href="eventpage.php">Link 2</a></li>
                                <li><a class="dropdown-item" href="eventpage.php">Link 3</a></li>
                            </ul>
                        </li>
                    <li class="nav-item">
                        <a class="nav-link ps-5" href="aboutuspage.php" style="font-size:20px; color: black;">About Us</a>
                    </li>
                    <li class="nav-item">
                        <button type="button" class="btn btn-nav nav-link ps-5" data-bs-toggle="modal" data-bs-target="#cartModal" style="font-size:20px;color:black"><i class="fa fa-shopping-cart"></i></button>
                    </li>
                </ul>
            </div>
            <div class="collapse navbar-collapse nav-right" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <button type="button" class="btn btn-nav nav-link ps-5" data-bs-toggle="modal" data-bs-target="#profileModal" style="font-size:20px; color: black;">Profile</button>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link ps-5 pe-5"  href="" style="font-size:20px; color: black;">Logout</a>
                    </li>
                </ul>
            </div>
<!--                <div class="collapse navbar-collapse nav-right" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link ps-5" href="registerpage.php" style="font-size:20px; color: black;">Register</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link ps-5 pe-5"  href="loginpage.php" style="font-size:20px; color: black;">Login</a>
                    </li>
                </ul>
            </div>-->
        </nav>
        
        <div class="container-fluid" style="margin-top:6%;width:90%">
            <h1>DYNAMIC CATEGORY NAME</h1>
            <p>bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla
             bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla
              bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla
               bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla
                bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla
                 bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla
                  bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla
                   bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla
                    bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla
                     bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla
                      bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla
            </p>
            <div class="container text-center my-5">
                <div class="row mx-auto my-auto justify-content-center">
                    <div id="recipeCarousel" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-inner" role="listbox">
                            <div class="carousel-item active">
                                <div class="col-md-3">
                                    <div class="card">
                                        <div class="card-img">
                                            <img src="//via.placeholder.com/500x400/31f?text=1" class="img-fluid">
                                        </div>
                                        <div class="card-img-overlay">Slide 1</div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="col-md-3">
                                    <div class="card">
                                        <div class="card-img">
                                            <img src="//via.placeholder.com/500x400/e66?text=2" class="img-fluid">
                                        </div>
                                        <div class="card-img-overlay">Slide 2</div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="col-md-3">
                                    <div class="card">
                                        <div class="card-img">
                                            <img src="//via.placeholder.com/500x400/7d2?text=3" class="img-fluid">
                                        </div>
                                        <div class="card-img-overlay">Slide 3</div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="col-md-3">
                                    <div class="card">
                                        <div class="card-img">
                                            <img src="//via.placeholder.com/500x400?text=4" class="img-fluid">
                                        </div>
                                        <div class="card-img-overlay">Slide 4</div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="col-md-3">
                                    <div class="card">
                                        <div class="card-img">
                                            <img src="//via.placeholder.com/500x400/aba?text=5" class="img-fluid">
                                        </div>
                                        <div class="card-img-overlay">Slide 5</div>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="col-md-3">
                                    <div class="card">
                                        <div class="card-img">
                                            <img src="//via.placeholder.com/500x400/fc0?text=6" class="img-fluid">
                                        </div>
                                        <div class="card-img-overlay">Slide 6</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a class="carousel-control-prev bg-transparent w-aut" href="#recipeCarousel" role="button" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        </a>
                        <a class="carousel-control-next bg-transparent w-aut" href="#recipeCarousel" role="button" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <div>
            <footer class="text-center justify-content-center">
                <ul style="list-style:none; display:flex;" class="justify-content-center pe-0 ps-0 pb-3 pt-5 m-0">
                    <li><a style="text-decoration:none;" class="footer" href="homePage.php">Home</a></li>
                    <li><a style="text-decoration:none;" class="footer" href="login.php">Login</a></li>
                    <li><a style="text-decoration:none;" class="footer" href="cart.php">Booking</a></li>
                    <li><a style="text-decoration:none;" class="footer" href="aboutUs.php">About</a></li>
                </ul>
                <div class="p-0 m-0">&copy 2023 Cookies by <b><i>Japanese Society</i></b> | All rights reserved</div>
            </footer>
        </div>
        
        <!---------------------------------------Modal Part---------------------------------------->
        
        <!--USER MODAL-->
        <!--USE THIS LINK TO LEARN HOW TO UPDATE DATA IN MODAL-->
        <!--https://www.sourcecodester.com/tutorials/php/12989/php-update-data-through-modal-dialog-using-mysqli.html-->
        <div id="profileModal" class="modal fade">
            <div class="modal-dialog modal modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="profileModal">Profile</h5>
                        <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="email" class="form-label">Email address : </label>
                                <input type="email" class="form-control" id="email">
                            </div>
                            <div class="mb-3">
                                <label for="username" class="form-label">Username : </label>
                                <input type="text" class="form-control" id="username">
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password : </label>
                                <input type="password" class="form-control" id="password">
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="form-label">Phone Number : </label>
                                <input type="tel" class="form-control" id="phone">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger me-auto" data-bs-dismiss="modal">Close</button>
                            <button type="submit" name="update" class="btn btn-success">Register</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <!--CART MODAL-->
        <div id="cartModal" class="modal fade">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="cartModal">Cart</h5>
                        <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        //This depends on you
                    </div>
                </div>
            </div>
        </div>
        
        <script>
            let items = document.querySelectorAll('.carousel .carousel-item')

            items.forEach((el) => {
                const minPerSlide = 4
                let next = el.nextElementSibling
                for (var i=1; i<minPerSlide; i++) {
                    if (!next) {
                        // wrap carousel by using first child
                            next = items[0]
                    }
                    let cloneChild = next.cloneNode(true)
                    el.appendChild(cloneChild.children[0])
                    next = next.nextElementSibling
                }
            })
        </script>
    </body>
</html>
