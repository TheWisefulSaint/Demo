<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://kit.fontawesome.com/24c9630061.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
        <link href="../CssPages/sidenav.css" rel="stylesheet" type="text/css"/>
    </head>
    <body style="overflow-y:hidden;">
        <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <h3 class="text-center">Japanese Society</h3>
                <strong>JS</strong>
            </div>
            
            <ul class="list-unstyled mt-2">
                <li class="bg-dark" style="pointer-events:none; color:white;">
                    <a>
                        <i class="fas fa-user"></i>
                    </a>
                </li>
            </ul>    

            <ul class="list-unstyled components">
                <li>
                    <a href="overviewpage.php">
                        <i class="far fa-clipboard"></i>
                        Overview
                    </a>
                </li>
                <li class="active">
                    <a href="admin-table.php">
                        <i class="fa-solid fa-user-shield"></i>
                        Admins
                    </a>
                </li>
                <li>
                    <a href="customer-table.php">
                        <i class="fa-solid fa-users"></i>
                        Users
                    </a>
                </li>
                <li>
                    <a href="event-table.php">
                        <i class="fas fa-calendar"></i>
                        Event
                    </a>
                </li>
                <li>
                    <a href="category-table.php">
                        <i class="fas fa-tags"></i>
                        Category
                    </a>
                </li>
                <li>
                    <a href="announcement-table.php">
                        <i class="fas fa-bullhorn"></i>
                        Announcement
                    </a>
                </li>
                <li class="mt-4">
                    <a href="../customerSide/logout.php">
                        <i class="fas fa-sign-out-alt"></i>
                        Log out
                    </a>
                </li>
            </ul>
        </nav>

        <!-- Page Content  -->
        <div id="content">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">
                    <button type="button" id="sidebarCollapse" class="btn btn-dark">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h2>Admin Page</h2>
                </div>
            </nav>
            
            <button type="button" class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#newAdminModal">Register New Admin</button>
            
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Phone No.</th>
                            <th>Created By</th>
                            <th>Creation Date</th>
                            <th>Updated By</th>
                            <th>Updated Date</th>
                            <th>Status</th>
                            <th>Role</th>
                            <th style="width:8%">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!--insert your php code-->
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td>
                                <button type="button" class="btn btn-primary float-start ms-3" data-bs-toggle="modal" data-bs-target="#editAdminModal"><i class="fa-solid fa-pencil"></i></button>
                                <button type="button" class="btn btn-danger float-end me-3" data-bs-toggle="modal" data-bs-target="#deleteAdminModal"><i class="fa-solid fa-trash-can"></i></button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        
        <div id="newAdminModal" class="modal fade">
            <div class="modal-dialog modal modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="newAdminModal">Create new admin</h5>
                        <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="email" class="form-label">Email address : </label>
                                <input type="email" class="form-control" id="email">
                            </div>
                            <div class="mb-3">
                                <label for="username" class="form-label">Username : </label>
                                <input type="text" class="form-control" id="username">
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password : </label>
                                <input type="password" class="form-control" id="password">
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="form-label">Phone Number : </label>
                                <input type="tel" class="form-control" id="phone">
                            </div>
                            <div class="mb-3">
                                <label for="role" class="form-label">Role : </label>
                                <select class="form-select" id="sel1" name="sellist1">
                                    <option>Admin</option>
                                    <option>Employee</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger me-auto" data-bs-dismiss="modal">Close</button>
                            <button type="submit" name="update" class="btn btn-success">Register</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <div id="editAdminModal" class="modal fade">
            <div class="modal-dialog modal modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="registerModal">Create new admin</h5>
                        <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form>
                        <div class="modal-body">
                            <div class="mb-3">
                                <label for="email" class="form-label">Email address : </label>
                                <input type="email" class="form-control" id="email">
                            </div>
                            <div class="mb-3">
                                <label for="username" class="form-label">Username : </label>
                                <input type="text" class="form-control" id="username">
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="form-label">Phone Number : </label>
                                <input type="tel" class="form-control" id="phone">
                            </div>
                            <div class="mb-3">
                                <label for="role" class="form-label">Role : </label>
                                <select class="form-select" id="sel1" name="sellist1">
                                    <option>Admin</option>
                                    <option>Employee</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger me-auto" data-bs-dismiss="modal">Close</button>
                            <button type="submit" name="update" class="btn btn-success">Register</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <div id="deleteAdminModal" class="modal fade">
                <div class="modal-dialog modal-sm modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-body">
                            <div class="mb-3 text-center">
                                <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
                                <h2 class="mb-4">Are you sure you want to delete</h2>
                                <button type="button" class="btn btn-danger me-auto float-start" data-bs-dismiss="modal">Close</button>
                                <button type="submit" name="delete" class="btn btn-success float-end">Delete</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        
        <script type="text/javascript">
            $(document).ready(function () 
            {
                $('#sidebarCollapse').on('click', function () 
                {
                    $('#sidebar').toggleClass('active');
                });
            });
        </script>
        </body>
</html>
