<!DOCTYPE html>

<?php
 
 $splineDataPoints = array(
    array("x" => 946665000000, "y" => 3289000),
    array("x" => 978287400000, "y" => 3830000),
    array("x" => 1009823400000, "y" => 2009000),
    array("x" => 1041359400000, "y" => 2840000),
    array("x" => 1072895400000, "y" => 2396000),
    array("x" => 1104517800000, "y" => 1613000),
    array("x" => 1136053800000, "y" => 1821000),
    array("x" => 1167589800000, "y" => 2000000),
    array("x" => 1199125800000, "y" => 1397000),
    array("x" => 1230748200000, "y" => 2506000),
    array("x" => 1262284200000, "y" => 6704000),
    array("x" => 1293820200000, "y" => 5704000),
    array("x" => 1325356200000, "y" => 4009000),
    array("x" => 1356978600000, "y" => 3026000),
    array("x" => 1388514600000, "y" => 2394000),
    array("x" => 1420050600000, "y" => 1872000),
    array("x" => 1451586600000, "y" => 2140000)
 );
 
$pieDataPoints1 = array( 
    array("label"=>"Industrial", "y"=>51.7),
    array("label"=>"Transportation", "y"=>26.6),
    array("label"=>"Residential", "y"=>13.9),
    array("label"=>"Commercial", "y"=>7.8)
);
        
$pieDataPoints2 = array( 
    array("label"=>"Industrial", "y"=>26.6),
    array("label"=>"Transportation", "y"=>51.7),
    array("label"=>"Residential", "y"=>13.9),
    array("label"=>"Commercial", "y"=>7.8)
);
 
$pieDataPoints3 = array( 
    array("label"=>"Industrial", "y"=>7.8),
    array("label"=>"Transportation", "y"=>13.9),
    array("label"=>"Residential", "y"=>26.6),
    array("label"=>"Commercial", "y"=>51.7)
);
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://kit.fontawesome.com/24c9630061.js" crossorigin="anonymous"></script>
        <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
        <link href="../CssPages/sidenav.css" rel="stylesheet" type="text/css"/>
    </head>
    <body style="overflow-y:hidden;">
        <script>
            window.onload = function() {
                var pieChart1 = new CanvasJS.Chart("pieChart1", {
                    animationEnabled: true,
                    backgroundColor: "#F5DEB3",
                    title: {
                            text: "World Energy Consumption by Sector - 2012"
                    },
                    data: [{
                            type: "pie",
                            indexLabel: "{y}",
                            yValueFormatString: "#,##0.00\"%\"",
                            indexLabelPlacement: "inside",
                            indexLabelFontColor: "#36454F",
                            indexLabelFontSize: 18,
                            indexLabelFontWeight: "bolder",
                            showInLegend: true,
                            legendText: "{label}",
                            dataPoints: <?php echo json_encode($pieDataPoints1, JSON_NUMERIC_CHECK); ?>
                    }]
                });
                var pieChart2 = new CanvasJS.Chart("pieChart2", {
                    animationEnabled: true,
                    backgroundColor: "#F5DEB3",
                    title: {
                            text: "World Energy Consumption by Sector - 2012"
                    },
                    data: [{
                            type: "pie",
                            indexLabel: "{y}",
                            yValueFormatString: "#,##0.00\"%\"",
                            indexLabelPlacement: "inside",
                            indexLabelFontColor: "#36454F",
                            indexLabelFontSize: 18,
                            indexLabelFontWeight: "bolder",
                            showInLegend: true,
                            legendText: "{label}",
                            dataPoints: <?php echo json_encode($pieDataPoints2, JSON_NUMERIC_CHECK); ?>
                    }]
                });
                var pieChart3 = new CanvasJS.Chart("pieChart3", {
                    animationEnabled: true,
                    backgroundColor: "#F5DEB3",
                    title: {
                            text: "World Energy Consumption by Sector - 2012"
                    },
                    data: [{
                            type: "pie",
                            indexLabel: "{y}",
                            yValueFormatString: "#,##0.00\"%\"",
                            indexLabelPlacement: "inside",
                            indexLabelFontColor: "#36454F",
                            indexLabelFontSize: 18,
                            indexLabelFontWeight: "bolder",
                            showInLegend: true,
                            legendText: "{label}",
                            dataPoints: <?php echo json_encode($pieDataPoints3, JSON_NUMERIC_CHECK); ?>
                    }]
                });
                var splineChart = new CanvasJS.Chart("splineChart", {
                    animationEnabled: true,
                    backgroundColor: "#F5DEB3",
                    title:{
                            text: "Company Revenue by Year"
                    },
                    axisY: {
                            title: "Revenue in USD",
                            valueFormatString: "#0,,.",
                            suffix: "mn",
                            prefix: "$"
                    },
                    data: [{
                            type: "spline",
                            markerSize: 5,
                            xValueFormatString: "YYYY",
                            yValueFormatString: "$#,##0.##",
                            xValueType: "dateTime",
                            dataPoints: <?php echo json_encode($splineDataPoints, JSON_NUMERIC_CHECK); ?>
                    }]
                });
                pieChart1.render();
                pieChart2.render();
                pieChart3.render();
                splineChart.render();

            };
            </script>
        <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <h3 class="text-center">Japanese Society</h3>
                <strong>JS</strong>
            </div>
            
            <ul class="list-unstyled mt-2">
                <li class="bg-dark" style="pointer-events:none; color:white;">
                    <a>
                        <i class="fas fa-user"></i>
                    </a>
                </li>
            </ul>    

            <ul class="list-unstyled components">
                <li class="active">
                    <a href="overviewpage.php">
                        <i class="far fa-clipboard"></i>
                        Overview
                    </a>
                </li>
                <li>
                    <a href="admin-table.php">
                        <i class="fa-solid fa-user-shield"></i>
                        Admins
                    </a>
                </li>
                <li>
                    <a href="customer-table.php">
                        <i class="fa-solid fa-users"></i>
                        Users
                    </a>
                </li>
                <li>
                    <a href="event-table.php">
                        <i class="fas fa-calendar"></i>
                        Event
                    </a>
                </li>
                <li>
                    <a href="category-table.php">
                        <i class="fas fa-tags"></i>
                        Category
                    </a>
                </li>
                <li>
                    <a href="announcement-table.php">
                        <i class="fas fa-bullhorn"></i>
                        Announcement
                    </a>
                </li>
                <li class="mt-4">
                    <a href="../customerSide/logout.php">
                        <i class="fas fa-sign-out-alt"></i>
                        Log out
                    </a>
                </li>
            </ul>
        </nav>

        <!-- Page Content  -->
        <div id="content">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">
                    <button type="button" id="sidebarCollapse" class="btn btn-dark">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h2>Overview</h2>
                </div>
            </nav>
            
            <div class="row mb-5 h-25">
                <div class="col p-0 mx-3" id="pieChart1"></div>
                <div class="col p-0 mx-3" id="pieChart2"></div>
                <div class="col p-0 mx-3" id="pieChart3"></div>
            </div>
            
            <div class="row mt-5 h-50">
                <div class="col mx-3 p-0" id="splineChart"></div>
            </div>
        </div>
        <script type="text/javascript">
            $(document).ready(function () 
            {
                $('#sidebarCollapse').on('click', function () 
                {
                    $('#sidebar').toggleClass('active');
                });
            });
        </script>
        </body>
</html>
