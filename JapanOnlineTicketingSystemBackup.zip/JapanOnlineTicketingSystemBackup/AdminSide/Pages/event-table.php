<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://kit.fontawesome.com/24c9630061.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.39.0/css/tempusdominus-bootstrap-4.min.css" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.39.0/js/tempusdominus-bootstrap-4.min.js"></script>
        <link href="../CssPages/sidenav.css" rel="stylesheet" type="text/css"/>
    </head>
    <body style="overflow-y:hidden;">
        <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <h3 class="text-center">Japanese Society</h3>
                <strong>JS</strong>
            </div>
            
            <ul class="list-unstyled mt-2">
                <li class="bg-dark" style="pointer-events:none; color:white;">
                    <a>
                        <i class="fas fa-user"></i>
                    </a>
                </li>
            </ul>    

            <ul class="list-unstyled components">
                <li>
                    <a href="overviewpage.php">
                        <i class="far fa-clipboard"></i>
                        Overview
                    </a>
                </li>
                <li>
                    <a href="admin-table.php">
                        <i class="fa-solid fa-user-shield"></i>
                        Admins
                    </a>
                </li>
                <li>
                    <a href="customer-table.php">
                        <i class="fa-solid fa-users"></i>
                        Users
                    </a>
                </li>
                <li class="active">
                    <a href="event-table.php">
                        <i class="fas fa-calendar"></i>
                        Event
                    </a>
                </li>
                <li>
                    <a href="category-table.php">
                        <i class="fas fa-tags"></i>
                        Category
                    </a>
                </li>
                <li>
                    <a href="announcement-table.php">
                        <i class="fas fa-bullhorn"></i>
                        Announcement
                    </a>
                </li>
                <li class="mt-4">
                    <a href="../customerSide/logout.php">
                        <i class="fas fa-sign-out-alt"></i>
                        Log out
                    </a>
                </li>
            </ul>
        </nav>

        <!-- Page Content  -->
        <div id="content">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">
                    <button type="button" id="sidebarCollapse" class="btn btn-dark">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h2>Event Page</h2>
                </div>
            </nav>
            
            <button type="button" class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#newEventModal">Create New Event</button>
            
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Event Name</th>
                            <th>Description</th>
                            <th>Category</th>
                            <th>Image</th>
                            <th>Created By</th>
                            <th>Creation Date</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Tickets</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!--insert your php code-->
                        <tr>
                            <td>1</th>
                            <td>Cincai name</td>
                            <td>Cincai description</td>
                            <td>Cincai cateogry</td>
                            <td>Cincai image</td>
                            <td>Cincai who</td>
                            <td>Cincai date</td>
                            <td>Cincai date</td>
                            <td>Cincai date</td>
                            <td><a href="ticket-table.php"><u>Cincai tickets</u></a></td>
                            <td>Cincai status</td>
                            <td>
                                <button type="button" class="btn btn-primary float-start" data-bs-toggle="modal" data-bs-target="#editEventModal"><i class="fa-solid fa-pencil"></i></button>
                                <button type="button" class="btn btn-danger float-end" data-bs-toggle="modal" data-bs-target="#deleteEventModal"><i class="fa-solid fa-trash-can"></i></button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <div id="newEventModal" class="modal fade">
                <div class="modal-dialog modal modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="newEventModal">Create new event</h5>
                            <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <form>
                            <div class="modal-body">
                                <div class="mb-3">
                                    <label for="eventName" class="form-label">Event Name : </label>
                                    <input type="text" class="form-control" id="eventName">
                                </div>
                                <div class="mb-3">
                                    <label for="description" class="form-label">Description : </label>
                                    <input type="text" class="form-control" id="description">
                                </div>
                                <div class="mb-3">
                                    <label for="category" class="form-label">Category : </label>
                                    <select class="form-select" id="category" name="category">
                                        <option>Tea</option>
                                        <option>Cosplay</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="image" class="form-label">Select an image to upload:</label>
                                    <input type="file" class="form-control" id="image">
                                </div>
                                <div class="mb-3">
                                    <div class="float-start mb-3">
                                        <label for="date" class="form-label">Start Date : </label>
                                        <input type="text" id="startDate" class="form-control datepicker" placeholder="Select start date" data-toggle="datetimepicker">
                                    </div>
                                    <div class="float-end mb-3">
                                        <label for="date" class="form-label">End Date : </label>
                                        <input type="text" id="endDate" class="form-control datepicker" placeholder="Select end date" data-toggle="datetimepicker">
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="ticketAmount" class="form-label">Enter ticket amount :</label>
                                    <input type="number" class="form-control" id="ticketAmount">
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger me-auto" data-bs-dismiss="modal">Close</button>
                                <button type="submit" name="update" class="btn btn-success">Register</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <div id="editEventModal" class="modal fade">
                <div class="modal-dialog modal modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editEventModal">Edit event</h5>
                            <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <form>
                            <div class="modal-body">
                                <div class="mb-3">
                                    <label for="eventName" class="form-label">Event Name : </label>
                                    <input type="text" class="form-control" id="eventName">
                                </div>
                                <div class="mb-3">
                                    <label for="description" class="form-label">Description : </label>
                                    <input type="text" class="form-control" id="description">
                                </div>
                                <div class="mb-3">
                                    <label for="category" class="form-label">Category : </label>
                                    <select class="form-select" id="category" name="category">
                                        <option>Tea</option>
                                        <option>Cosplay</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="image" class="form-label">Select an image to upload:</label>
                                    <input type="file" class="form-control" id="image">
                                </div>
                                <div class="mb-3">
                                    <div class="float-start mb-3">
                                        <label for="date" class="form-label">Start Date : </label>
                                        <input type="text" id="startDate" class="form-control datepicker" placeholder="Select start date" data-toggle="datetimepicker">
                                    </div>
                                    <div class="float-end mb-3">
                                        <label for="date" class="form-label">End Date : </label>
                                        <input type="text" id="endDate" class="form-control datepicker" placeholder="Select end date" data-toggle="datetimepicker">
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="ticketAmount" class="form-label">Enter ticket amount :</label>
                                    <input type="number" class="form-control" id="ticketAmount">
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger me-auto" data-bs-dismiss="modal">Close</button>
                                <button type="submit" name="update" class="btn btn-success">Edit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <div id="deleteEventModal" class="modal fade">
                <div class="modal-dialog modal-sm modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-body">
                            <div class="mb-3 text-center">
                                <button type="button" class="btn-close float-end" data-bs-dismiss="modal" aria-label="Close"></button>
                                <h2 class="mb-4">Are you sure you want to delete</h2>
                                <button type="button" class="btn btn-danger me-auto float-start" data-bs-dismiss="modal">Close</button>
                                <button type="submit" name="delete" class="btn btn-success float-end">Delete</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
        <script type="text/javascript">
            $(document).ready(function () 
            {
                $('#sidebarCollapse').on('click', function () 
                {
                    $('#sidebar').toggleClass('active');
                });
            });
            
            $(document).ready(function() {
                $('.datepicker').datetimepicker({
                    format: 'DD-MM-YYYY'
                });
            });
        </script>
        </body>
</html>
