<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://kit.fontawesome.com/24c9630061.js" crossorigin="anonymous"></script>
        <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
        <link href="../CssPages/sidenav.css" rel="stylesheet" type="text/css"/>
    </head>
    <body style="overflow-y:hidden;">
        <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <h3 class="text-center">Japanese Society</h3>
                <strong>JS</strong>
            </div>
            
            <ul class="list-unstyled mt-2">
                <li class="bg-dark" style="pointer-events:none; color:white;">
                    <a>
                        <i class="fas fa-user"></i>
                    </a>
                </li>
            </ul>    

            <ul class="list-unstyled components">
                <li>
                    <a href="overviewpage.php">
                        <i class="far fa-clipboard"></i>
                        Overview
                    </a>
                </li>
                <li>
                    <a href="admin-table.php">
                        <i class="fa-solid fa-user-shield"></i>
                        Admins
                    </a>
                </li>
                <li>
                    <a href="customer-table.php">
                        <i class="fa-solid fa-users"></i>
                        Users
                    </a>
                </li>
                <li class="active">
                    <a href="event-table.php">
                        <i class="fas fa-calendar"></i>
                        Event
                    </a>
                </li>
                <li>
                    <a href="category-table.php">
                        <i class="fas fa-tags"></i>
                        Category
                    </a>
                </li>
                <li>
                    <a href="announcement-table.php">
                        <i class="fas fa-bullhorn"></i>
                        Announcement
                    </a>
                </li>
                <li class="mt-4">
                    <a href="../customerSide/logout.php">
                        <i class="fas fa-sign-out-alt"></i>
                        Log out
                    </a>
                </li>
            </ul>
        </nav>

        <!-- Page Content  -->
        <div id="content">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">
                    <button type="button" id="sidebarCollapse" class="btn btn-dark">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h2>Ticket Page</h2>
                </div>
            </nav>
            
            <h5 style="text-align: center">Tickets from Cincai Event</h5>
            
            <div class="table" style="width:50%; margin-left:25%">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Ticket ID</th>
                            <th>Purchased By</th>
                            <th>Purchased Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!--insert your php code-->
                        <tr>
                        </tr>
                    </tbody>
                </table>
            </div>
            
        </div>
        <script type="text/javascript">
            $(document).ready(function () 
            {
                $('#sidebarCollapse').on('click', function () 
                {
                    $('#sidebar').toggleClass('active');
                });
            });
        </script>
        </body>
</html>
